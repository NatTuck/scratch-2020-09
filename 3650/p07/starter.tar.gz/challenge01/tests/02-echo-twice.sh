echo one
echo two
