FOO=one
BAR=two
echo $FOO $BAR $FOO
FOO=three
echo $BAR $FOO $BAR
